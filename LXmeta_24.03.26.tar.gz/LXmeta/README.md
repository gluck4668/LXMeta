# LXMeta
This R package can be used to analyze the metabolite enrichment and the related metabolism pathways.
